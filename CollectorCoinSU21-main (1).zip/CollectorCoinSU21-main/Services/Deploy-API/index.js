const express = require('express');
const http = require('http');
const app = express();

const port = process.env.PORT || 5000;
const server = http.createServer(app);
const io = require('socket.io')(server, {
    cors: {
        origin: '*',
        methods: ['GET', 'POST', 'PUT', 'OPTIONS']
    }
});

io.on('connection', (socket) => {
    console.log(`connected to ${socket.id}`);
    //console.log(socket)

    io.emit('broadcast', 'broadcasting');

    socket.on('reply', () => { 'replied!' });
});

app.use(function(req,res,next){
    req.io = io;
    next();
});

require('./startup/routes')(app);
server.listen(port);

module.exports = server;
