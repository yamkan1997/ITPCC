const express = require('express');
const router = express.Router();
const asyncMiddleware = require('../middleware/async');

const config = require('config');
const { ethers, utils } = require('ethers');
const abi = require('../contracts/abi/CCProjectFactory.json');

const env = process.env.NODE_ENV;
const privKey = config.get('privKey');
const apiKey = config.get('providerKey');
const network = config.get('network');
const contractAddress = config.get('contractAddress');

router.post('/', asyncMiddleware(async (req, res) => {
    let provider = new ethers.providers.InfuraProvider(network,apiKey); 
    let wallet = new ethers.Wallet(privKey, provider);
    let contract = new ethers.Contract(contractAddress, abi, wallet);
    console.log(`deploying new project on: ${network}`);
    console.log(`using wallet address ${wallet.address}`);
    console.log(`with factory contract ${contractAddress}`);

    let processed = false;
    let tx = {};

    try{
        await provider.ready;
        /**
            string memory _vin,
            string memory _make,
            string memory _model,
            bool _vinMatched,
            uint256 _msrp,
            uint256 _fundingGoal
         */
        let vin = req.body['vin'];
        let make = req.body['make'];
        let model = req.body['model'];
        let vinMatched = req.body['vinMatched'];
        let msrp = req.body['msrp'];
        let fundingGoal = req.body['fundingGoal'];

        tx = await contract.createNewProject(
            vin,
            make,
            model,
            vinMatched,
            msrp,
            fundingGoal
            );
        //tx = await provider.getBlock('latest');
        processed = true;
    }
    catch(ex) {
        console.log('new project failed deployment');
        console.log(ex);
    }
    finally {
        console.log(`request processed: ${processed}`);
        (processed) ? res.send(tx) 
            : res.send('failed to deploy\n');
    }
}));

module.exports = router;