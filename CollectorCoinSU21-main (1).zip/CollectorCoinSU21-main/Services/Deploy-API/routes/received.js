const express = require('express');
const router = express.Router();
const asyncMiddleware = require('../middleware/async');

const env = process.env.NODE_ENV;

router.post('/', asyncMiddleware(async (req, res) => {
    //let didReceived = req.body['received'];
    req.io.emit('received', req.body);
    res.send(`title received: ${req.body['received']}`); 
}));

module.exports = router;