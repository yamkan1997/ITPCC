const express = require('express');
const router = express.Router();
const asyncMiddleware = require('../middleware/async');

const env = process.env.NODE_ENV;

router.post('/', asyncMiddleware(async (req, res) => {
    //let isVerified = req.body['verified'];
    req.io.emit('verified', req.body);
    res.send(`details verified: ${req.body['verified']}`); 
}));

module.exports = router;