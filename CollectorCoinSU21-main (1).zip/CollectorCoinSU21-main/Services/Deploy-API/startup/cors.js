const cors = require('cors');

const corsOptions = {
    origin: true
}

module.exports = function(app) {
    app.use(cors())
}