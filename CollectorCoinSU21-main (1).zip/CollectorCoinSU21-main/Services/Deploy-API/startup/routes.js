const express = require('express');
const main = require('../routes/main');
const deploy = require('../routes/deploy');
const verified = require('../routes/verified');
const received = require('../routes/received');

const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {
    app.set('trust proxy', 1);
    app.use(express.json());
    app.use('/', main);
    app.use('/deploy', deploy);
    app.use('/verified', verified);
    app.use('/received', received);
    app.use('/kie-server', createProxyMiddleware({
        target: 'http://deployment-api:8080',
        changeOrigin: true,
        onProxyRes: function (proxyRes, req, res) {
            proxyRes.headers['Access-Control-Allow-Origin'] = '*';
        }
    }));
}
