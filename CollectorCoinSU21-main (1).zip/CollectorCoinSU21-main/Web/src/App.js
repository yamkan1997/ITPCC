import React from "react"
import Topbar from "./components/Topbar"
import Navigation from "./Navigation"
import Copyright from "./components/Copyright";
import UserSocket from "./services/socket";

import ProjectsState from './context/projects/ProjectsState';

const App = () => {
    if (window.ethereum && window.ethereum.isMetaMask) {
        return (
            <div>
                <ProjectsState>
                    <Topbar />
                    <UserSocket />
                    <Navigation />
                    <Copyright />
                </ProjectsState>
            </div>
        )
    } else {
        return (
            <div>This app requires the Metamask Extension to be installed.</div>
            )
    }
}

export default App
