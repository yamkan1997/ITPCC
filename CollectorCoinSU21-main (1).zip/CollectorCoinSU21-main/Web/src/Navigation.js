
import React from "react"
import {BrowserRouter, Switch, Route} from "react-router-dom";
import Home from "./views/Home/";
import Buyer from "./views/Buyer/";
import Signin from "./views/Auth/Signin";
import SignUp from "./views/Auth/Signup";
import CollectorCoinSwap from "./views/CollectorCoinSwap/";
import About from "./views/About";
import Project from "./views/Project";
import ApproveListing from "./views/ApproveListing";
import Dashboard from "./views/AdminPanel";
import AdminWeb3 from "./views/AdminWeb3";
import UserWeb3 from "./components/Web3Interface";
import NewListing from "./views/NewListing";
import InvestNow from "./views/InvestNow";
import Portfolio from "./views/Portfolio";
import BuyerPortfolio from "./views/BuyerPortfolio";

const Navigation = () => {
    return (
        <BrowserRouter>
            <Switch>

                <Route
                    path={"/"}
                    exact
                    component={Home}
                />

                <Route
                    path={"/buyer"}
                    exact
                    component={Buyer}
                />

                <Route
                    path={"/project/:project_id"}
                    exact
                    component={Project}
                />

                <Route
                    path={"/listing/:process_id/:task_id/:task_type"}
                    exact
                    component={ApproveListing}
                />

                <Route
                    path={"/signin"}
                    exact
                    component={Signin}
                />
                <Route
                    path={"/signup"}
                    exact
                    component={SignUp}
                />

                <Route
                    path={"/swap-coin"}
                    exact
                    component={CollectorCoinSwap}
                />

                <Route
                    path={"/about"}
                    exact
                    component={About}
                />

                <Route
                    path={"/newlisting"}
                    exact
                    component={NewListing}
                />

                <Route
                    path={"/admin"}
                    exact
                    component={Dashboard}
                />

                <Route
                    path={"/admin-web3"}
                    exact
                    component={AdminWeb3}
                />

                <Route
                    path={"/user-web3"}
                    exact
                    component={UserWeb3}
                />

                <Route
                    path={"/modal"}
                    exact
                    component={InvestNow}
                />

                <Route
                    path={"/portfolio"}
                    exact
                    component={Portfolio}
                />

                <Route
                    path={"/buyer-portfolio"}
                    exact
                    component={BuyerPortfolio}
                />

            </Switch>
        </BrowserRouter>
    )
}

export default Navigation