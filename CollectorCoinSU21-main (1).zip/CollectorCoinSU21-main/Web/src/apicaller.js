const URL_FRAGMENT = process.env.REACT_APP_API_JBPM_URL;

export async function callApi(endpoint, http_method, payload) {
    const url = `${URL_FRAGMENT}/${endpoint}`;
    const headers = {
        'Authorization': 'Basic '+btoa('wbadmin:wbadmin'),
        'content-type': 'application/json',
    }
    const requestOptions = (payload) 
        ? {
            crossDomain:true,
            headers,
            method: http_method,
            body: JSON.stringify(payload)
        }
        : {
            crossDomain:true,
            headers,
            method: http_method
        }
        
    console.log('url: ', url)
    
    return await fetch(url, requestOptions)
        .then(async (response) => {
            console.log(response)
            if (!response.ok) {
                return response.json()
                    .then((json) => {
                        return Promise.reject(json)
                    });
            }
            return response.json();
        });
}
