import React, {useEffect, useState} from 'react';
import { ethers } from 'ethers';

import Button from '@material-ui/core/Button';

import FactoryABI from '../../contracts/abi/CCProjectFactory.json';
import ProjectABI from '../../contracts/abi/CCProject.json';
const factoryAddress = '0x0ac94Dbac97E3ae4fa6a6b02785e07a6d18ab6F9';

let contract;

export default function ConnectMetaMask (props) {
    const [connected, setConnected] = useState(false);

    useEffect( () => {
        initialize();
    }, [])

    const initialize = async () => {
        await window.ethereum.request({ method: 'eth_requestAccounts'});
        await window.ethereum.request({
            method: 'wallet_switchEthereumChain',
            params: [{ chainId: '0x4'}]
        })
        const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
        await provider.send('eth_requestAccounts', []);
        const signer = provider.getSigner();
        contract = new ethers.Contract(factoryAddress, FactoryABI, signer);
        let account;
        account = await signer.getAddress();
        console.log('Account: ', account);
        (account && account.length > 0) ? setConnected(true) : setConnected(false);
        let projects = await contract.getProjects();
        console.log(projects);
        for await(let address of projects) {
            console.log('********N E W * * * P R O J E C T********');
            // get the project address
            console.log('project: ', address);

            // instantiate a new project contract from available project addresses
            let projectContract = new ethers.Contract(address, ProjectABI, signer);

            // check if the project is active
            let active = await projectContract.isActive();
            if (!active) continue;

            let vin = await projectContract.vinNumber();
            console.log('vin number: ', vin);

            let make = await projectContract.make();
            console.log('make: ', make);

            let model = await projectContract.model();
            console.log('model: ', model);
            
            let vinMatched = await projectContract.vinMatched();
            console.log('vin matched: ', vinMatched);
            
            let msrp = await projectContract.msrp();
            console.log('msrp: ', msrp.toString());
            
            let goal = await projectContract.fundingGoal();
            console.log('funding goal: ', goal.toString());
            
            let shareLeft = await projectContract.shareLeft();
            console.log('share left: ', shareLeft.toString());
            
            let totalDeposit = await projectContract.totalDeposit();
            console.log('total deposit: ', totalDeposit.toString());
            
            let fundingToGoal = await projectContract.getFundingToGoal();
            console.log('funding to goal: ', fundingToGoal.toString());
            console.log('* * * * * * * * * * * * * * * *');
        }
    }

    let buttonText = (connected) ? 'Connected' : 'Connect';
    console.log(connected)
    window.ethereum.on('chainChanged', (_chainId) => window.location.reload());
    //window.addEventListener('DOMContentLoaded', initialize)
    return (
        <Button
            variant="outlined"
            color="inherit"
            onClick={() => {initialize()}}
        >
            {buttonText}
        </Button>
    );

}
