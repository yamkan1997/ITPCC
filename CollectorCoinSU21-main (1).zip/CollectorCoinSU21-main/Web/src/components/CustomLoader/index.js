
import React from "react";
import Loader from "react-spinners/BeatLoader";

const CustomLoader = (props) => {
    let value = props.data
    if (value === 0)
        return 0
    return (
        <div style={{display: "inline"}}>
            {value? value: <Loader color={'black'} loading={true} size={8} margin={2} />}
        </div>
    )
}

export default CustomLoader