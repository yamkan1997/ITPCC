import React from 'react';
import MetaMaskOnboarding from '@metamask/onboarding';

const currentUrl = new URL(window.location.href);
const forwarderOrigin = currentUrl.hostname === 'localhost' 
    ? 'http://localhost:9010'
    : undefined;

const isMetaMaskInstalled = () => {
    const { ethereum } = window;
    return Boolean(ethereum && ethereum.isMetaMask);
}

const initialize = () => {

    let accounts;
    const isMetaMaskConnected = () => accounts && accounts.length > 0;

    // const MetaMaskClientCheck = () => {
    //     if (!isMetaMaskInstalled()) {
    //         onboardButton.innerText = 'Click here to install MetaMask!'
    //         onboardButton.onclick = onClickInstall
    //         onboardButton.disabled = false
    //       } else if (isMetaMaskConnected()) {
    //         onboardButton.innerText = 'Connected'
    //         onboardButton.disabled = true
    //         if (onboarding) {
    //           onboarding.stopOnboarding()
    //         }
    //       } else {
    //         onboardButton.innerText = 'Connect'
    //         onboardButton.onclick = onClickConnect
    //         onboardButton.disabled = false
    //       }
    // };
    // MetaMaskClientCheck();
}

export default function InitWeb3 (props) {
    return(
        <div>{window.addEventListener('DOMContentLoaded', initialize)}</div>
    );
}