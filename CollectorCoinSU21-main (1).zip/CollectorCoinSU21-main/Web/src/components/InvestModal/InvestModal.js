import React, {useState} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import Grid from "@material-ui/core/Grid";
import {approveFunding, fundProject} from "../Web3Interface";
import CustomSnackbar from "../CustomSnackbar";

function getModalStyle() {
    const top = 50;
    const left = 50;

    return {
        top: `${top}%`,
        left: `${left}%`,
        transform: `translate(-${top}%, -${left}%)`,
    };
}

const useStyles = makeStyles((theme) => ({
    paper: {
        position: 'absolute',
        width: 400,
        backgroundColor: theme.palette.background.paper,
        border: '2px solid #000',
        boxShadow: theme.shadows[5],
        padding: theme.spacing(2, 4, 3),
    },
}));

export default function InvestModal(props) {
    const {openModal, onClose, details} = props;
    const classes = useStyles();
    const [modalStyle] = React.useState(getModalStyle);

    const [investAmount, setInvestAmount] = useState("")
    const [openInvestAlert, setOpenInvestAlert] = useState(false)


    function investInProject() {
        if (details && investAmount > 0)
            approveFunding(details.id)
                .then(() => fundProject(details.id, investAmount)
                    .then(() => setOpenInvestAlert(true)))
    }

    const body = (
        <div style={modalStyle} className={classes.paper}>
            <CustomSnackbar open={openInvestAlert} setOpen={() => setOpenInvestAlert(!openInvestAlert)} text={"Successfully invested in the project"}/>

            <h2 id="simple-modal-title" style={{textAlign: "center"}}>Invest</h2>
            <div id="simple-modal-description">
                <p>Amount Raised: ${details?.totalDeposit?.toNumber()}</p>
                <p>Amount Remaining: {details?.goal?.toNumber() - details?.totalDeposit?.toNumber()
                    ? "$"+details?.goal?.toNumber() - details?.totalDeposit?.toNumber()
                    : 0}</p>
            </div>
            <Grid container>
                <Grid item xs={6}>
                    <form noValidate autoComplete="off">
                        <TextField
                            id="standard-basic"
                            label="Amount"
                            type={"number"}
                            value={investAmount}
                            onChange={(event) => {
                                var value = event.target.value
                                if (value <= details?.goal?.toNumber() - details?.totalDeposit?.toNumber() && value >= 0) {
                                    setInvestAmount(value)
                                }
                            }}
                        />
                    </form>
                </Grid>
            </Grid>
            <div align={"right"}>
                <Button
                    variant="contained"
                    color={"primary"}
                    onClick={() => investInProject()}
                >
                    Invest Now
                </Button>
            </div>
        </div>
    );

    return (
        <Modal
            open={openModal}
            onClose={() => onClose()}
            aria-labelledby="simple-modal-title"
            aria-describedby="simple-modal-description"
        >
            {body}
        </Modal>
    );
}
