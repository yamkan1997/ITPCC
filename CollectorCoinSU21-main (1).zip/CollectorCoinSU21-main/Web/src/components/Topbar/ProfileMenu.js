import React from 'react';
import Button from '@material-ui/core/Button';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import AccountCircleIcon from "@material-ui/icons/AccountCircle";

export default function ProfileMenu(props) {
    const {onValueChange} = props;

    const [anchorEl, setAnchorEl] = React.useState(null);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = (value) => {
        if (value === "Investor" || value === "Buyer" || value === "Admin") onValueChange(value)

        setAnchorEl(null);
    };

    return (
        <div>
            <Button
                color={"inherit"}
                aria-controls="simple-menu"
                aria-haspopup="true"
                onClick={handleClick}
            >
                <AccountCircleIcon />
            </Button>
            <Menu
                id="simple-menu"
                anchorEl={anchorEl}
                keepMounted
                open={Boolean(anchorEl)}
                onClose={handleClose}
            >
                <MenuItem onClick={() => handleClose('Investor')}>Investor</MenuItem>
                <MenuItem onClick={() => handleClose('Buyer')}>Buyer</MenuItem>
                <MenuItem onClick={() => handleClose('Admin')}>Admin</MenuItem>
            </Menu>
        </div>
    );
}
