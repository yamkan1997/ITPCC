import React, {useEffect, useState} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import {Container} from "@material-ui/core";
import ConnectMetaMask from '../ConnectMetaMask';
import ProfileMenu from './ProfileMenu'
import {getCCTokenBalance} from "../Web3Interface";

const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
    },
    menuButton: {
        marginRight: theme.spacing(2),
    },
    title: {
        flexGrow: 1,
    },
}));

export default function ButtonAppBar() {

    const classes = useStyles();

    const [ccTokenBalance, setCCTokenBalance] = useState("0");


    useEffect(() => {
        if (localStorage.getItem("role") === null ) localStorage.setItem("role", "Investor");
    }, [])

    useEffect(() => {
        getCCTokenBalance()
            .then((data) => {
                setCCTokenBalance(data)
            })
    }, [])

    let role = localStorage.getItem("role");

    const BuyerNavbar = () => {
        return (
            <Typography variant="h6" className={classes.title}>
                CollectorCoin
                <Button href="/buyer" color="inherit">Buyer Home</Button>
                <Button href="/buyer-portfolio" color="inherit">My Portfolio</Button>
            </Typography>
        )
    }

    const AdminNavbar = () => {
        return (
            <Typography variant="h6" className={classes.title}>
                CollectorCoin
                <Button href="/admin" color="inherit">Admin Panel</Button>
                <Button href="/" color="inherit">Investor Home</Button>
                <Button href="/buyer" color="inherit">Buyer Home</Button>
                <Button href="/apis" color="inherit">Test APIS</Button>
                <Button href="/admin-web3" color="inherit">Admin Web3</Button>

            </Typography>
        )
    }

    const InvestorNavbar = () => {
        return (
            <Typography variant="h6" className={classes.title}>
                CollectorCoin
                <Button href="/" color="inherit">Home</Button>
                <Button href="/portfolio" color="inherit">My Portfolio</Button>
                <Button href="/newlisting" color="inherit">New Project</Button>
            </Typography>
        )
    }

    return (
        <div className={classes.root}>
            <AppBar position="static">
                <Container maxWidth={"lg"}>
                <Toolbar>
                    {role === "Admin" && <AdminNavbar/>}
                    {role === "Investor" && <InvestorNavbar/>}
                    {role === "Buyer" && <BuyerNavbar/>}


                    {/*<Button href="/signin" color="inherit">Sign In</Button>*/}
                    {/*<Button href="/signup" color="inherit">Sign Up</Button>*/}

                    <Button href="/about" color="inherit">About Us</Button>
                    <Button href="/swap-coin" color="inherit">Balance: {ccTokenBalance}</Button>
                    <ConnectMetaMask />
                    <ProfileMenu
                        onValueChange={(data) => {
                            localStorage.setItem('role', data);
                            if (data === "Buyer") {
                                window.location.href='/buyer'
                            } else if (data === "Admin") {
                                window.location.href='/admin'
                            } else {
                                window.location.href='/'
                            }
                        }}
                    />

                </Toolbar>
                </Container>
            </AppBar>
        </div>
    );
}
