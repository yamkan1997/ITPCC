import React, {useEffect, useState} from "react"
import {Link} from "react-router-dom";
import {ethers} from 'ethers';

import Button from "@material-ui/core/Button"
import {Container, Grid} from "@material-ui/core";
import {makeStyles} from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import Paper from '@material-ui/core/Paper';

import StableTokenABI from '../../contracts/abi/StableToken.json';
import FactoryABI from '../../contracts/abi/CCProjectFactory.json';
import ProjectABI from '../../contracts/abi/CCProject.json';
import CCTokenABI from '../../contracts/abi/CCSwapToken.json';
import FaucetABI from '../../contracts/abi/CCFaucet.json';

const stableTokenAddress = process.env.REACT_APP_STABLE_TOKEN_ADDRESS;
const faucetAddress = process.env.REACT_APP_FAUCET_ADDRESS;
const ccTokenAddress = process.env.REACT_APP_CC_TOKEN_ADDRESS;
const factoryAddress = process.env.REACT_APP_FACTORY_ADDRESS;
const APPROVAL_AMOUNT = '0xffffffffffffffffffffffff'


const useStyles = makeStyles({
    root: {
        minWidth: 200,
        margin: '10px 0 0 0',
    },
    title: {
        fontSize: 18
    },
    pos: {
        marginBottom: 10,
    },
});

export const getCCTokenBalance = async () => {
    try{
        await window.ethereum.request({ method: 'eth_requestAccounts'});
        const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
        await provider.send('eth_requestAccounts', []);
        const signer = provider.getSigner();
        const ccTokenContract = new ethers.Contract(ccTokenAddress, CCTokenABI, signer);
        let account = await signer.getAddress();
        let balance = await ccTokenContract.balanceOf(account);
        return await ethers.utils.commify(balance)
    } catch (ex) {
        console.log(ex)
    }
}

export const approveSwap = async() => {
    try{
        await window.ethereum.request({ method: 'eth_requestAccounts'});
        const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
        await provider.send('eth_requestAccounts', []);
        const signer = provider.getSigner();
        const contract = new ethers.Contract(stableTokenAddress, StableTokenABI, signer);
        let tx = await contract.approve(ccTokenAddress, APPROVAL_AMOUNT);
        return tx.hash

    } catch (ex) {
        console.log(ex)
    }
}

export const swapTokens = async(fundAmount) => {
    try{
        await window.ethereum.request({ method: 'eth_requestAccounts'});
        const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
        await provider.send('eth_requestAccounts', []);
        const signer = provider.getSigner();
        const contract = new ethers.Contract(ccTokenAddress, CCTokenABI, signer);
        let tx = await contract.deposit(fundAmount);
        return tx.hash
    } catch (ex) {
        console.log(ex)
    }
}

export const redeemTokens = async(fundAmount) => {
    try{
        await window.ethereum.request({ method: 'eth_requestAccounts'});
        const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
        await provider.send('eth_requestAccounts', []);
        const signer = provider.getSigner();
        const contract = new ethers.Contract(ccTokenAddress, CCTokenABI, signer);
        let tx = await contract.redeem(fundAmount);
        return tx.hash
    } catch (ex) {
        console.log(ex)
    }
}

export const getProjectIds = async () => {
    try{
        await window.ethereum.request({ method: 'eth_requestAccounts'});
        const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
        await provider.send('eth_requestAccounts', []);
        const signer = provider.getSigner();
        const factoryContract = new ethers.Contract(factoryAddress, FactoryABI, signer);
        return await factoryContract.getProjects()
    } catch (ex) {
        console.log(ex)
    }
}

export const getProjectDetails = async (projectContract) => {
    try{
        await window.ethereum.request({ method: 'eth_requestAccounts'});
        const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
        await provider.send('eth_requestAccounts', []);
        const signer = provider.getSigner();
        const contract = new ethers.Contract(projectContract, ProjectABI, signer);
        let active = await contract.isActive();
        let vin = await contract.vinNumber();
        let make = await contract.make();
        let model = await contract.model();
        let vinMatched = await contract.vinMatched();
        let msrp = await contract.msrp();
        let goal = await contract.fundingGoal();
        let shareLeft = await contract.shareLeft();
        let totalDeposit = await contract.totalDeposit();
        let fundingToGoal = await contract.getFundingToGoal();
        let redeemable = await contract.canRedeem();

        let details = {
            "id": projectContract,
            "active": active,
            "redeemable": redeemable,
            "vin": vin,
            "make": make,
            "model": model,
            "vinMatched": vinMatched,
            "msrp": msrp,
            "goal": goal,
            "shareLeft": shareLeft,
            "totalDeposit": totalDeposit,
            "fundingToGoal": fundingToGoal
        }
        return details
    } catch (ex) {
        console.log(ex)
    }
}

export const getFunderDetails = async (projectContract) => {
    let result;
    try{
        await window.ethereum.request({ method: 'eth_requestAccounts'});
        const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
        await provider.send('eth_requestAccounts', []);
        const signer = provider.getSigner();
        const contract = new ethers.Contract(projectContract, ProjectABI, signer);
        let account = await signer.getAddress();
        result = await contract.funders(account);
        console.log(result)
    } catch (ex) {
        console.log(ex)
    }
    return result;
}

export const approveFunding = async(projectContract) => {
    try{
        await window.ethereum.request({ method: 'eth_requestAccounts'});
        const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
        await provider.send('eth_requestAccounts', []);
        const signer = provider.getSigner();
        const contract = new ethers.Contract(ccTokenAddress, CCTokenABI, signer);
        let tx = await contract.approve(projectContract, APPROVAL_AMOUNT);
        return tx.hash
    } catch (ex) {
        console.log(ex)
    }
}

export const fundProject = async (projectContract, fundAmount) => {
    try{
        await window.ethereum.request({ method: 'eth_requestAccounts'});
        const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
        await provider.send('eth_requestAccounts', []);
        const signer = provider.getSigner();
        const contract = new ethers.Contract(projectContract, ProjectABI, signer);
        let tx = await contract.fund(fundAmount);
        return tx.hash
    } catch (ex) {
        console.log(ex)
    }
}

export const deactivate = async (projectContract) => {
    try{
        await window.ethereum.request({ method: 'eth_requestAccounts'});
        const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
        await provider.send('eth_requestAccounts', []);
        const signer = provider.getSigner();
        const contract = new ethers.Contract(factoryAddress, FactoryABI, signer);
        let tx = await contract.deactivate(projectContract);
        return tx.hash
    } catch (ex) {
        console.log(ex)
    }
}

export const withdrawFunds = async (projectContract) => {
    try{
        await window.ethereum.request({ method: 'eth_requestAccounts'});
        const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
        await provider.send('eth_requestAccounts', []);
        const signer = provider.getSigner();
        const contract = new ethers.Contract(factoryAddress, FactoryABI, signer);
        let tx = await contract.withdrawFunding(projectContract);
        return tx.hash
    } catch (ex) {
        console.log(ex)
    }
}

export const dripFaucet = async() => {
    try{
        await window.ethereum.request({ method: 'eth_requestAccounts'});
        const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
        await provider.send('eth_requestAccounts', []);
        const signer = provider.getSigner();
        const contract = new ethers.Contract(faucetAddress, FaucetABI, signer);
        let tx = await contract.drip();
        return tx.hash
    } catch (ex) {
        console.log(ex)
    }
}

export const recoupFunds = async (projectContract) => {
    try{
        await window.ethereum.request({ method: 'eth_requestAccounts'});
        const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
        await provider.send('eth_requestAccounts', []);
        const signer = provider.getSigner();
        const contract = new ethers.Contract(projectContract, ProjectABI, signer);
        let tx = await contract.recoup();
        return tx.hash
    } catch (ex) {
        console.log(ex)
    }
}

const UserWeb3 = () => {
    const classes = useStyles();
    const [ccTokenBalance, setCCTokenBalance] = useState("0");
    const [projectAddresses, setProjectAddresses] = useState([]);
    const [projectContract, setProjectContract] = useState("");
    const [projectDetails, setProjectDetails] = useState({});
    const [fundAmount, setFundAmount] = useState("0");
    const [txHash, setTxHash] = useState("");

    useEffect(() => {
        getCCTokenBalance()
            .then((data) => {
                console.log(data)
                setCCTokenBalance(data)
            })
    }, [])

    const recoupFundsLocal = async () => {
        try{
            await window.ethereum.request({ method: 'eth_requestAccounts'});
            const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
            await provider.send('eth_requestAccounts', []);
            const signer = provider.getSigner();
            const contract = new ethers.Contract(projectContract, ProjectABI, signer);
            let tx = await contract.recoup();
            setTxHash(tx.hash);
        } catch (ex) {
            console.log(ex)
        }
    }

    return (
        <div>
            <Container maxWidth="sm">
                <Typography component="h1" variant="h2" align="center" color="textPrimary" gutterBottom>
                    User Functions
                </Typography>
            </Container>
            <Container>
                <Grid container>
                    <Grid item xs={6}>
                        <div>
                        <Card className={classes.root}>
                            <CardContent>
                                <Typography className={classes.title} color="textSecondary" gutterBottom>
                                    CC Token Balance
                                </Typography>
                                <Typography className={classes.title} color="textSecondary" gutterBottom>
                                    {ccTokenBalance}
                                </Typography>
                            </CardContent>
                        </Card>
                        </div>

                        <div>
                            <Paper elevation={3} variant='outlined'>
                                <h3>Stable Token Faucet</h3>
                                <Button variant="contained" onClick={() => recoupFundsLocal()}>
                                    Drip
                                </Button>
                                
                                <Card className={classes.root}>
                                    <CardContent>
                                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                                            <Link to={{ pathname: `https://rinkeby.etherscan.io/tx/${txHash}` }} target="_blank">
                                                {txHash}
                                            </Link>
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Paper>
                        </div>

                        <div>
                            <Paper elevation={3} variant='outlined'>
                                <h3>Approve Swap</h3>
                                <Button variant="contained" onClick={() => approveSwap().then(data => setTxHash(data))}>
                                    Approve
                                </Button>
                                
                                <Card className={classes.root}>
                                    <CardContent>
                                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                                            <Link to={{ pathname: `https://rinkeby.etherscan.io/tx/${txHash}` }} target="_blank">
                                                {txHash}
                                            </Link>
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Paper>
                        </div>

                        <div>
                            <Paper elevation={3} variant='outlined'>
                                <h3>Swap Tokens</h3>
                                <form className={classes.root} noValidate autoComplete="off">
                                    <TextField id="standard-basic" label="Swap Amount" onChange={(event) => setFundAmount(event.target.value)}/>
                                </form>
                                <Button variant="contained" onClick={() => swapTokens(fundAmount).then(data => setTxHash(data))}>
                                    Swap
                                </Button>
                                
                                <Card className={classes.root}>
                                    <CardContent>
                                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                                            <Link to={{ pathname: `https://rinkeby.etherscan.io/tx/${txHash}` }} target="_blank">
                                                {txHash}
                                            </Link>
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Paper>
                        </div>
                        
                        <div>
                            <Paper elevation={3} variant='outlined'>
                                <h3>List Project Addresses</h3>
                                <Button variant="contained" onClick={() => getProjectIds().then((data) => setProjectAddresses(data))}>
                                    List
                                </Button>
                                <Card className={classes.root}>
                                    <CardContent>
                                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                                        {
                                            projectAddresses.map((e, i) => {
                                                return (<li key={i}>{e}</li>)
                                            })
                                        }
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Paper>
                        </div>

                        <div>
                            <Paper elevation={3} variant='outlined'>
                                <h3>List Project Details</h3>
                                <form className={classes.root} noValidate autoComplete="off">
                                    <TextField id="standard-basic" label="Project Address" onChange={(event) => setProjectContract(event.target.value)}/>
                                </form>
                                <Button variant="contained" onClick={() => getProjectDetails().then(data => setProjectDetails(data))}>
                                    Details
                                </Button>
                            
                                <Card className={classes.root}>
                                    <CardContent>
                                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                                            <li key={1}>{`Active: ${projectDetails.active}`}</li>
                                            <li key={2}>{`Vin: ${projectDetails.vin}`}</li>
                                            <li key={3}>{`Make: ${projectDetails.make}`}</li>
                                            <li key={4}>{`Model: ${projectDetails.model}`}</li>
                                            <li key={5}>{`Vin Matched: ${projectDetails.vinMatched}`}</li>
                                            <li key={6}>{`MSRP: $${projectDetails.msrp}`}</li>
                                            <li key={7}>{`Goal: $${projectDetails.goal}`}</li>
                                            <li key={8}>{`Share Left: ${projectDetails.shareLeft}%`}</li>
                                            <li key={9}>{`Total Deposits: $${projectDetails.totalDeposit}`}</li>
                                            <li key={10}>{`Funding to go: $${projectDetails.fundingToGoal}`}</li>
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Paper>
                        </div>

                        <div>
                            <Paper elevation={3} variant='outlined'>
                                <h3>Approve Funding</h3>
                                <form className={classes.root} noValidate autoComplete="off">
                                    <TextField id="standard-basic" label="Project Address" onChange={(event) => setProjectContract(event.target.value)}/>
                                </form>
                                <Button variant="contained" onClick={() => approveFunding((data) => setTxHash(data))}>
                                    Approve
                                </Button>
                                
                                <Card className={classes.root}>
                                    <CardContent>
                                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                                            <Link to={{ pathname: `https://rinkeby.etherscan.io/tx/${txHash}` }} target="_blank">
                                                {txHash}
                                            </Link>
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Paper>
                        </div>

                        <div>
                            <Paper elevation={3} variant='outlined'>
                                <h3>Fund a Project</h3>
                                <form className={classes.root} noValidate autoComplete="off">
                                    <TextField id="standard-basic" label="Project Address" onChange={(event) => setProjectContract(event.target.value)}/>
                                </form>
                                <form className={classes.root} noValidate autoComplete="off">
                                    <TextField id="standard-basic" label="Fund Amount" onChange={(event) => setFundAmount(event.target.value)}/>
                                </form>
                                <Button variant="contained" onClick={() => fundProject((data) => setTxHash(data))}>
                                    Fund
                                </Button>
     
                                <Card className={classes.root}>
                                    <CardContent>
                                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                                            <Link to={{ pathname: `https://rinkeby.etherscan.io/tx/${txHash}` }} target="_blank">
                                                {txHash}
                                            </Link>
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Paper>
                        </div>

                        <div>
                            <Paper elevation={3} variant='outlined'>
                                <h3>Recoup Proceeds</h3>
                                <form className={classes.root} noValidate autoComplete="off">
                                    <TextField id="standard-basic" label="Project Address" onChange={(event) => setProjectContract(event.target.value)}/>
                                </form>
                                <Button variant="contained" onClick={() => recoupFunds()}>
                                    Recoup
                                </Button>
                                
                                <Card className={classes.root}>
                                    <CardContent>
                                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                                            <Link to={{ pathname: `https://rinkeby.etherscan.io/tx/${txHash}` }} target="_blank">
                                                {txHash}
                                            </Link>
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Paper>
                        </div>

                    </Grid>
                </Grid>
            </Container>
        </div>
    )
}

export default UserWeb3