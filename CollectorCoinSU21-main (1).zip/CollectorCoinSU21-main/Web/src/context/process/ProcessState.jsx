import React, { useReducer } from 'react';
import ProcessContext from './processContext';
import processReducer from './processReducer';
import { SET_NEW_PROJECT, REMOVE_PROJECT_ID } from '../types';

const ProcessState = ({ children }) => {
    const initialState = {
        projects: [],
    };

    const [state, dispatch] = useReducer(processReducer, initialState);

    const setProject = (project) => {
        dispatch({
            type: SET_NEW_PROJECT,
            payload: project,
        });
    }

    return (
        <ProcessContext.Provider
            value={{
                projects: state.projects,
                setProject,
            }}
        >
            {children}
        </ProcessContext.Provider>
    );
};

export default ProcessState;
