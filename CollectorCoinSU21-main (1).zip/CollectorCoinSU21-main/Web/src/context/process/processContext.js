import { createContext } from 'react';

const processContext = createContext();
processContext.displayName = 'process';

export default processContext;