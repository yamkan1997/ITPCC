import { REMOVE_PROJECT_ID, SET_NEW_PROJECT } from "../types";

const processReducer = (state, action) => {
    switch (action.type) {
        case SET_NEW_PROJECT:
            return {
                ...state, 
                projects: action.payload
            };
        case REMOVE_PROJECT_ID:
            return state.filter(p => p.id !== action.payload);
        default:
            return state;
    }
};

export default processReducer;
