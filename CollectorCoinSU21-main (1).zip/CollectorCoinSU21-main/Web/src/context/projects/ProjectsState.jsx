import React, { useReducer } from 'react';
import ProjectsContext from './projectsContext';
import projectsReducer from './projectsReducer';
import { SET_NEW_PROJECT, REMOVE_PROJECT_ID } from '../types';

const ProjectsState = ({ children }) => {
    const initialState = {
        projects: [
            {
            "procId": 0,
            "id": "uuid",
            "vin": "vin",
            "make": "carMake",
            "model": "carModel",
            "vinMatched": true,
            "msrp": "msrp",
            "fundingGoal": "goal",
            "detailsVerified": false,
            "titleReceived": false
            }
        ],
    };

    const [state, dispatch] = useReducer(projectsReducer, initialState);

    const setProject = (project) => {
        dispatch({
            type: SET_NEW_PROJECT,
            payload: project,
        });
    }

    return (
        <ProjectsContext.Provider
            value={{
                projects: state.projects,
                setProject,
            }}
        >
            {children}
        </ProjectsContext.Provider>
    );
};

export default ProjectsState;
