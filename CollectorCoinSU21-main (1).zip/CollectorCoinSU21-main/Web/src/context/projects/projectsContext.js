import { createContext } from 'react';

const projectsContext = createContext();
projectsContext.displayName = 'projects';

export default projectsContext;