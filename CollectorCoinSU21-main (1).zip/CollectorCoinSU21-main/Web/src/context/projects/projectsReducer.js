import { REMOVE_PROJECT_ID, SET_NEW_PROJECT } from "../types";

const projectsReducer = (state, action) => {
    switch (action.type) {
        case SET_NEW_PROJECT:
            return {
                ...state, 
                projects: [...state.projects, action.payload]
            };
        case REMOVE_PROJECT_ID:
            return state.filter(p => p.id !== action.payload);
        default:
            return state;
    }
};

export default projectsReducer;
