// Process
export const SET_NEW_PROJECT = 'SET_NEW_PROJECT';
export const REMOVE_PROJECT_ID = 'REMOVE_PROJECT_ID';