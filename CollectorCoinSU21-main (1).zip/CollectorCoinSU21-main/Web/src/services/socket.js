import { useEffect, useContext } from 'react';
import io from 'socket.io-client';

import projectsContext from '../context/projects/projectsContext';

const ENDPOINT = process.env.REACT_APP_API_DEPLOY_URL;

const UserSocket = () => {
  const { setProject } = useContext(projectsContext);

  useEffect(() => {
    const socket = io(ENDPOINT);

    socket.on('connect', () => {
      console.log('connected with id: ', socket.id);
    });

    socket.on('broadcast', data => {
      console.log(data);
    });

    socket.on('verified', data => {
      console.log(`project id: ${data.id}`);
      console.log(`details approved: ${data.verified}`);
      window.location.reload()
    });

    socket.on('received', data => {
      console.log(`project id: ${data.id}`);
      console.log(`title received: ${data.received}`);
    });

  }, []);

  return null;
};

export default UserSocket;
