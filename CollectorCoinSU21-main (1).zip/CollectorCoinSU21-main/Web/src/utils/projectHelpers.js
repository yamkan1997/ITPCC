import { callApi } from "../apicaller";

const REST_FRAGMENT = 'kie-server/services/rest/server';

export async function startTasksFromID(processId) {
    let tasks = [];
    let data;
    try {
        data = await callApi(`${REST_FRAGMENT}/queries/tasks/instances/process/${processId}`, 'GET', null);
        if (data) {
            data["task-summary"].map((r) =>
                tasks.push(r["task-id"])
            )
        }
        if (tasks.length > 0) {
            for await (let t of tasks) {
                callApi(`${REST_FRAGMENT}/containers/Submission_Process_1.0.0-SNAPSHOT/tasks/${t}/states/started`, 'PUT', null);
            }
        }
    }
    catch (ex) {
        console.log("Errored on start tasks:::");
        console.log(ex);
    }
}

export async function getTasks() {
    let procIds = [];
    let tasks = [];
    let data;
    // get all process instances
    data = await callApi(`${REST_FRAGMENT}/queries/containers/Submission_Process_1.0.0-SNAPSHOT/process/instances`, 'GET', null);
    if (data) {
        data["process-instance"].map((r) =>
            procIds.push(r["process-instance-id"])
        )
    }

    // get tasks per procId
    for await (let p of procIds) {
        data = await callApi(`${REST_FRAGMENT}/queries/tasks/instances/process/${p}`, 'GET', null);
        if (data) {
            data["task-summary"].map((r) =>

                tasks.push({
                    procId: p,
                    taskId: r["task-id"],
                    name: r["task-name"],
                    status: r["task-status"]
                })
            )
        }
    }

    // return array of tasks
    return tasks; 
}

export async function getDetails(procId) {
    let data;
    let details = {};
    try {
        data = await callApi(`${REST_FRAGMENT}/queries/processes/instances/${procId}/variables/instances`, 'GET', null);
        let results = data['variable-instance']
        if (results && results.length>0) {
            results.map(obj => {
                details.id = (obj.name === 'id') ? obj.value : details.id
                details.vin = (obj.name === 'vin') ? obj.value : details.vin
                details.make = (obj.name === 'make') ? obj.value : details.make
                details.model = (obj.name === 'model') ? obj.value : details.model
                details.vinMatched = (obj.name === 'vinMatched') ? obj.value : details.vinMatched
                details.msrp = (obj.name === 'msrp') ? obj.value : details.msrp
                details.fundingGoal = (obj.name === 'fundingGoal') ? obj.value : details.fundingGoal
                details.initiator = (obj.name === 'initiator') ? obj.value : details.initiator
            })
        }
    }
    catch (ex) {
        console.log("Error getting listing details for approval");
        console.log(ex);
    }
    finally {
        return details;
    }
}

export async function completeTask(taskId, taskType, decision) {
    let body = {};
    switch (taskType) {
        case 'Verify-Details':
            body = { "detailsVerified": decision }
            await callApi(`${REST_FRAGMENT}/containers/Submission_Process_1.0.0-SNAPSHOT/tasks/${taskId}/states/completed`, 'PUT', body);
        case 'Receive-Title':
            body = { "titleReceived": decision }
            await callApi(`kie-server/services/rest/server/containers/Submission_Process_1.0.0-SNAPSHOT/tasks/${taskId}/states/completed`, 'PUT', body);
        default:
    }
}