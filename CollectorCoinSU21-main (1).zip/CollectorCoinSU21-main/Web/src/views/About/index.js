
import React from "react";
import {Container} from "@material-ui/core";
import Typography from "@material-ui/core/Typography";
import {makeStyles} from "@material-ui/core/styles";

const useStyles = makeStyles((theme) => ({
    heroContent: {
        padding: theme.spacing(8, 0, 6),
    },
}));

const About = () => {
    const classes = useStyles();

    return (
        <div style={{marginTop: "40px", textAlign: "justify"}}>
            <Container maxWidth={"md"}>
                <div className={classes.heroContent}>
                    <Container maxWidth="sm">
                        <Typography component="h1" variant="h2" align="center" color="textPrimary" gutterBottom>
                            About Collector Coin
                        </Typography>
                    </Container>
                </div>
                <p style={{fontSize: "large"}}>
                    CollectorCoin(CC) is an innovative new tokenization method that uses the value of “hard assets”, such as collector cars, as the core of its monetary worth. CC is essentially a crowd-funded hard assets investment platform. Big and small-time investors can, using the security that the Ethereum blockchain provides, buy stakes in collector projects, such as the restoration of collector cars. Because the blockchain provides an immutable record of ownership, CC allows investors of any size to buy into collector projects and reap rewards proportionate to their investments down the line. Investing in projects such as the restoration of collector cars is daunting, has a very high barrier to entry, and is often incredibly inefficient. However, using CC’s new blockchain system in place, virtually anyone with a computer and a small sum of money will be able to diversify investments into the restoration of collector cars.
                </p>
                <p style={{fontSize: "large"}}>
                    DLM Group, Inc. is a real estate holding company that provides services to the collector car market. It currently manages the online Cadillac Database for the Cadillac LaSalle Club and the Cadillac LaSalle Museum and Research Center, which attracts a community of more than 7,000 members
                </p>
            </Container>
        </div>
    )
}

export default About