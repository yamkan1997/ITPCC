import React, {useState, useEffect} from 'react';
import Link from '@material-ui/core/Link';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Title from './Title';
import Button from "@material-ui/core/Button";

import {getTasks} from '../../utils/projectHelpers';
import {shorten} from '../../utils/shortAddress';
import {
    getProjectIds, 
    getProjectDetails,
    deactivate,
    withdrawFunds } from "../../components/Web3Interface";

const ENDPOINT = process.env.REACT_APP_API_ETHERSCAN_URL;

function preventDefault(event) {
    event.preventDefault();
}

const useStyles = makeStyles((theme) => ({
    seeMore: {
        marginTop: theme.spacing(3),
    },
}));

export default function Orders() {
    const classes = useStyles();

    const [rows, setRows] = useState([]);
    const [details, setDetails] = useState([]);

    // Replace with fetch data

    // Generate Order Data
    function createData(id, proc, task, title, status, action) {
        return { id, proc, task, title, status, action};
    }

    useEffect(async() => {
        let data = await getProjectIds()
        let deets = []
        for await (let id of data) {
            let deet = await getProjectDetails(id)
            deets.push(deet)
        }
        setDetails(deets)
    }, [])

    async function buildRows() {
        let tasks = await getTasks();
        let rows = [];
        if(tasks.length>0) {
            tasks.map(t => {
                rows.push(createData(
                    t.taskId, 
                    t.procId,
                    t.taskId,
                    (t.name === 'Verify Details') ? 'Verify-Details' : 'Receive-Title',
                    t.status,
                    'Verify'
                ));
            });
        }
        if(details.length>0) {
            details.map(d => {
                if(d.active && d.fundingToGoal.toString() === '0') {
                    console.log('active',d.id, d.active)
                    rows.push(createData(
                        d.id,
                        shorten(d.id),
                        'Withdraw',
                        'Contract',
                        'Funded',
                        'Withdraw'
                    ));
                }
            })
        }
        return rows;
    }
    useEffect(async () => {
        let result = await buildRows();
        setRows(result);
    }, [details]);

    const withdraw = async (id) => {
        try {
            await deactivate(id);
            await withdrawFunds(id);
        }
        catch (ex) {
            console.log('withdraw tx failed:::');
            console.log(ex);
        }
    }

    return (
        <React.Fragment>
            <Title>Recent Projects</Title>
            <Table size="small">
                <TableHead>
                    <TableRow>
                        <TableCell>Process</TableCell>
                        <TableCell>Task</TableCell>
                        <TableCell>Title</TableCell>
                        <TableCell align="right">Status</TableCell>
                        <TableCell align="right">Action</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {rows.map((row) => (
                        <TableRow key={row.id}>
                            <TableCell>{(row.title === 'Contract') 
                                ?   <a href={`${ENDPOINT}/${row.id}`} target='_blank'>{row.proc}</a>
                                :   row.proc}
                                </TableCell>
                            <TableCell>{row.task}</TableCell>
                            <TableCell>{(row.title === 'Contract') ? 'Contract' : (row.title === 'Verify-Details') ? 'Verify Details' : 'Receive Title'}</TableCell>
                            <TableCell align="right">{row.status}</TableCell>
                            {(row.title === 'Contract') 
                                ?   <TableCell align="right"><Button variant={"outlined"} color={"primary"} onClick={() => withdraw(row.id)}>{row.action}</Button></TableCell> 
                                :   <TableCell align="right"><Button variant={"outlined"} color={"primary"} href={`/listing/${row.proc}/${row.task}/${row.title}`}>{row.action}</Button></TableCell>
                            }
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
            <div className={classes.seeMore}>
                <Link color="primary" href="#" onClick={preventDefault}>
                    See All Projects
                </Link>
            </div>
        </React.Fragment>
    );
}