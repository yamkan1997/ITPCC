import React, { useState, useContext } from "react"
import { Link } from "react-router-dom";
import { ethers } from 'ethers';

import Button from "@material-ui/core/Button"
import {Container, Grid} from "@material-ui/core";
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import Paper from '@material-ui/core/Paper';

import ProjectsContext from '../../context/projects/projectsContext';

import FactoryABI from '../../contracts/abi/CCProjectFactory.json';
import ProjectABI from '../../contracts/abi/CCProject.json';
import CCTokenABI from '../../contracts/abi/CCSwapToken.json';
import StableTokenABI from '../../contracts/abi/StableToken.json';
import FaucetABI from '../../contracts/abi/CCFaucet.json';

const stableTokenAddress = process.env.REACT_APP_STABLE_TOKEN_ADDRESS;
const faucetAddress = process.env.REACT_APP_FAUCET_ADDRESS;
const ccTokenAddress = process.env.REACT_APP_CC_TOKEN_ADDRESS;
const factoryAddress = process.env.REACT_APP_FACTORY_ADDRESS;
const APPROVAL_AMOUNT = '0xffffffffffffffffffffffff'

const useStyles = makeStyles({
    root: {
        minWidth: 200,
        margin: '10px 10px 0 0',
    },
    title: {
        fontSize: 18
    },
    pos: {
        marginBottom: 10,
    },
});

const AdminWeb3 = () => {
    const classes = useStyles();

    const { projects } = useContext(ProjectsContext);

    const [ccTokenBalance, setCCTokenBalance] = useState("0");
    const [projectAddresses, setProjectAddresses] = useState([]);
    const [projectContract, setProjectContract] = useState("");
    const [projectDetails, setProjectDetails] = useState({});
    const [transferAmount, setTransferAmount] = useState("0");
    const [transferAddress, setTransferAddress] = useState("0");
    const [txHash, setTxHash] = useState("");

    const getCCTokenBalance = async () => {
        try{
            await window.ethereum.request({ method: 'eth_requestAccounts'});
            const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
            await provider.send('eth_requestAccounts', []);
            const signer = provider.getSigner();
            const ccTokenContract = new ethers.Contract(ccTokenAddress, CCTokenABI, signer);
            let account = await signer.getAddress();
            let balance = await ccTokenContract.balanceOf(account);
            setCCTokenBalance(ethers.utils.commify(balance));
        } catch (ex) {
            console.log(ex)
        }
    }
    getCCTokenBalance();

    const dripFaucet = async() => {
        try{
            await window.ethereum.request({ method: 'eth_requestAccounts'});
            const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
            await provider.send('eth_requestAccounts', []);
            const signer = provider.getSigner();
            const contract = new ethers.Contract(faucetAddress, FaucetABI, signer);
            let tx = await contract.drip();
            setTxHash(tx.hash);
        } catch (ex) {
            console.log(ex)
        }
    }

    const approveSwap = async() => {
        try{
            await window.ethereum.request({ method: 'eth_requestAccounts'});
            const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
            await provider.send('eth_requestAccounts', []);
            const signer = provider.getSigner();
            const contract = new ethers.Contract(stableTokenAddress, StableTokenABI, signer);
            let tx = await contract.approve(ccTokenAddress, APPROVAL_AMOUNT);
            setTxHash(tx.hash);

        } catch (ex) {
            console.log(ex)
        }
    }

    const swapTokens = async() => {
        try{
            await window.ethereum.request({ method: 'eth_requestAccounts'});
            const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
            await provider.send('eth_requestAccounts', []);
            const signer = provider.getSigner();
            const contract = new ethers.Contract(ccTokenAddress, CCTokenABI, signer);
            let tx = await contract.deposit(transferAmount);
            setTxHash(tx.hash);
        } catch (ex) {
            console.log(ex)
        }
    }

    const getProjectIds = async () => {
        try{
            await window.ethereum.request({ method: 'eth_requestAccounts'});
            const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
            await provider.send('eth_requestAccounts', []);
            const signer = provider.getSigner();
            const factoryContract = new ethers.Contract(factoryAddress, FactoryABI, signer);
            let projects = await factoryContract.getProjects();
            setProjectAddresses(projects);
        } catch (ex) {
            console.log(ex)
        }
    }

    const getProjectDetails = async () => {
        try{
            await window.ethereum.request({ method: 'eth_requestAccounts'});
            const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
            await provider.send('eth_requestAccounts', []);
            const signer = provider.getSigner();
            const contract = new ethers.Contract(projectContract, ProjectABI, signer);
            let active = await contract.isActive();
            let vin = await contract.vinNumber();
            let make = await contract.make();
            let model = await contract.model();
            let vinMatched = await contract.vinMatched();
            let msrp = await contract.msrp();
            let goal = await contract.fundingGoal();
            let shareLeft = await contract.shareLeft();
            let totalDeposit = await contract.totalDeposit();
            let fundingToGoal = await contract.getFundingToGoal();

            let details = {
                "active": active ? 'true' : 'false',
                "vin": vin,
                "make": make,
                "model": model,
                "vinMatched": vinMatched,
                "msrp": msrp,
                "goal": goal,
                "shareLeft": shareLeft,
                "totalDeposit": totalDeposit,
                "fundingToGoal": fundingToGoal
            }

            setProjectDetails(details);
        } catch (ex) {
            console.log(ex)
        }
    }

    const approveDeposit = async() => {
        try{
            await window.ethereum.request({ method: 'eth_requestAccounts'});
            const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
            await provider.send('eth_requestAccounts', []);
            const signer = provider.getSigner();
            const contract = new ethers.Contract(factoryAddress, FactoryABI, signer);
            let tx = await contract.approveDeposits(projectContract, APPROVAL_AMOUNT);
            setTxHash(tx.hash);
        } catch (ex) {
            console.log(ex)
        }
    }

    const deactivate = async () => {
        try{
            await window.ethereum.request({ method: 'eth_requestAccounts'});
            const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
            await provider.send('eth_requestAccounts', []);
            const signer = provider.getSigner();
            const contract = new ethers.Contract(factoryAddress, FactoryABI, signer);
            let tx = await contract.deactivate(projectContract);
            setTxHash(tx.hash);
        } catch (ex) {
            console.log(ex)
        }
    }

    const withdrawFunding = async () => {
        try{
            await window.ethereum.request({ method: 'eth_requestAccounts'});
            const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
            await provider.send('eth_requestAccounts', []);
            const signer = provider.getSigner();
            const contract = new ethers.Contract(factoryAddress, FactoryABI, signer);
            let tx = await contract.withdrawFunding(projectContract);
            setTxHash(tx.hash);
        } catch (ex) {
            console.log(ex)
        }
    }

    const transferFunding = async () => {
        try{
            await window.ethereum.request({ method: 'eth_requestAccounts'});
            const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
            await provider.send('eth_requestAccounts', []);
            const signer = provider.getSigner();
            const contract = new ethers.Contract(factoryAddress, FactoryABI, signer);
            let tx = await contract.transferFunding(transferAddress, transferAmount);
            setTxHash(tx.hash);
        } catch (ex) {
            console.log(ex)
        }
    }

    const transferProceeds = async () => {
        try{
            await window.ethereum.request({ method: 'eth_requestAccounts'});
            const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
            await provider.send('eth_requestAccounts', []);
            const signer = provider.getSigner();
            const contract = new ethers.Contract(ccTokenAddress, CCTokenABI, signer);
            let tx = await contract.transfer(factoryAddress, transferAmount);
            setTxHash(tx.hash);
        } catch (ex) {
            console.log(ex)
        }
    }

    const depositProceeds = async () => {
        try{
            await window.ethereum.request({ method: 'eth_requestAccounts'});
            const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
            await provider.send('eth_requestAccounts', []);
            const signer = provider.getSigner();
            const contract = new ethers.Contract(factoryAddress, FactoryABI, signer);
            let tx = await contract.depositProceeds(projectContract, transferAmount);
            setTxHash(tx.hash);
        } catch (ex) {
            console.log(ex)
        }
    }

    return (
        <div>
        {console.log(projects)}
            <Container maxWidth="sm">
                <Typography component="h1" variant="h2" align="center" color="textPrimary" gutterBottom>
                    Admin Functions
                </Typography>
            </Container>
            <Container>
                <Grid container>
                    <Grid item xs={6}>
                        <div>
                        <Card className={classes.root}>
                            <CardContent>
                                <Typography className={classes.title} color="textSecondary" gutterBottom>
                                    CC Token Balance
                                </Typography>
                                <Typography className={classes.title} color="textSecondary" gutterBottom>
                                    {ccTokenBalance}
                                </Typography>
                            </CardContent>
                        </Card>
                        </div>

                        <div>
                        <Paper elevation={3} variant='outlined'>
                          <h3>Get Stable Tokens</h3>
                          <h5>This will deposit 10000 Stable Tokens into the connected account</h5>
                          <Button variant="contained" onClick={() => dripFaucet()}>
                              Drip
                          </Button>

                          <Card className={classes.root}>
                              <CardContent>
                                  <Typography className={classes.title} color="textSecondary" gutterBottom>
                                      <Link to={{ pathname: `https://rinkeby.etherscan.io/tx/${txHash}` }} target="_blank">
                                          {txHash}
                                      </Link>
                                  </Typography>
                              </CardContent>
                          </Card>
                        </Paper>
                        </div>

                        <div>
                        <Paper elevation={3} variant='outlined'>
                          <h3>Approve Swap</h3>
                          <h5>Approve the swap of Stable Tokens into CC Tokens</h5>
                          <Button variant="contained" onClick={() => approveSwap()}>
                              Approve
                          </Button>

                          <Card className={classes.root}>
                              <CardContent>
                                  <Typography className={classes.title} color="textSecondary" gutterBottom>
                                      <Link to={{ pathname: `https://rinkeby.etherscan.io/tx/${txHash}` }} target="_blank">
                                          {txHash}
                                      </Link>
                                  </Typography>
                              </CardContent>
                          </Card>
                        </Paper>
                        </div>

                        <div>
                        <Paper elevation={3} variant='outlined'>
                          <h3>Swap Stable Tokens</h3>
                          <h5>Swap Stable Tokens for CC Tokens</h5>
                          <Button variant="contained" onClick={() => swapTokens()}>
                              Swap
                          </Button>
                          <form className={classes.root} noValidate autoComplete="off">
                                  <TextField id="standard-basic" label="Transfer Amount" onChange={(event) => setTransferAmount(event.target.value)}/>
                          </form>
                          <Card className={classes.root}>
                              <CardContent>
                                  <Typography className={classes.title} color="textSecondary" gutterBottom>
                                      <Link to={{ pathname: `https://rinkeby.etherscan.io/tx/${txHash}` }} target="_blank">
                                          {txHash}
                                      </Link>
                                  </Typography>
                              </CardContent>
                          </Card>
                        </Paper>
                        </div>

                        <div>
                            <Paper elevation={3} variant='outlined'>
                                <h3>List Project Addresses</h3>
                                <h5>List all projects registered with the factory</h5>
                                <Button variant="contained" onClick={() => getProjectIds()}>
                                    List
                                </Button>

                                <Card className={classes.root}>
                                    <CardContent>
                                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                                        {
                                            projectAddresses.map((e, i) => {
                                                return (<li key={i}>{e}</li>)
                                            })
                                        }
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Paper>
                        </div>

                        <div>
                            <Paper elevation={3} variant='outlined'>
                                <h3>List Project Details</h3>
                                <form className={classes.root} noValidate autoComplete="off">
                                    <TextField id="standard-basic" label="Project Address" onChange={(event) => setProjectContract(event.target.value)}/>
                                </form>
                                <Button variant="contained" onClick={() => getProjectDetails()}>
                                    Details
                                </Button>

                                <Card className={classes.root}>
                                    <CardContent>
                                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                                            <li key={1}>{`Active: ${projectDetails.active}`}</li>
                                            <li key={2}>{`Vin: ${projectDetails.vin}`}</li>
                                            <li key={3}>{`Make: ${projectDetails.make}`}</li>
                                            <li key={4}>{`Model: ${projectDetails.model}`}</li>
                                            <li key={5}>{`Vin Matched: ${projectDetails.vinMatched}`}</li>
                                            <li key={6}>{`MSRP: $${projectDetails.msrp}`}</li>
                                            <li key={7}>{`Goal: $${projectDetails.goal}`}</li>
                                            <li key={8}>{`Share Left: ${projectDetails.shareLeft}%`}</li>
                                            <li key={9}>{`Total Deposits: $${projectDetails.totalDeposit}`}</li>
                                            <li key={10}>{`Funding to go: $${projectDetails.fundingToGoal}`}</li>
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Paper>
                        </div>

                        <div>
                            <Paper elevation={3} variant='outlined'>
                                <h3>Deactivate a Project</h3>
                                <h5>Once the funding goal is reached, project must be deactivated to transfer funding</h5>
                                <form className={classes.root} noValidate autoComplete="off">
                                    <TextField id="standard-basic" label="Project Address" onChange={(event) => setProjectContract(event.target.value)}/>
                                </form>
                                <Button variant="contained" onClick={() => deactivate()}>
                                    Deactivate
                                </Button>

                                <Card className={classes.root}>
                                    <CardContent>
                                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                                            <Link to={{ pathname: `https://rinkeby.etherscan.io/tx/${txHash}` }} target="_blank">
                                                {txHash}
                                            </Link>
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Paper>
                        </div>

                        <div>
                            <Paper elevation={3} variant='outlined'>
                                <h3>Withdraw Funding</h3>
                                <h5>After project hits funding goal and is deactivated, pull funding for restoration</h5>
                                <form className={classes.root} noValidate autoComplete="off">
                                    <TextField id="standard-basic" label="Project Address" onChange={(event) => setProjectContract(event.target.value)}/>
                                </form>
                                <Button variant="contained" onClick={() => withdrawFunding()}>
                                    Withdraw to Factory
                                </Button>

                                <Card className={classes.root}>
                                    <CardContent>
                                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                                            <Link to={{ pathname: `https://rinkeby.etherscan.io/tx/${txHash}` }} target="_blank">
                                                {txHash}
                                            </Link>
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Paper>
                        </div>

                        <div>
                            <Paper elevation={3} variant='outlined'>
                                <h3>Transfer Funding</h3>
                                <h5>Transfer funding to a restorer to begin restoration</h5>
                                <form className={classes.root} noValidate autoComplete="off">
                                    <TextField id="standard-basic" label="Restorer Address" onChange={(event) => setTransferAddress(event.target.value)}/>
                                </form>
                                <form className={classes.root} noValidate autoComplete="off">
                                        <TextField id="standard-basic" label="Transfer Amount" onChange={(event) => setTransferAmount(event.target.value)}/>
                                </form>
                                <Button variant="contained" onClick={() => transferFunding()}>
                                    Transfer
                                </Button>

                                <Card className={classes.root}>
                                    <CardContent>
                                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                                            <Link to={{ pathname: `https://rinkeby.etherscan.io/tx/${txHash}` }} target="_blank">
                                                {txHash}
                                            </Link>
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Paper>
                        </div>

                        <div>
                            <Paper elevation={3} variant='outlined'>
                                <h3>Transfer Proceeds</h3>
                                <h5>Add the project proceeds back to the factory in order to deposit to the project contract</h5>
                                <form className={classes.root} noValidate autoComplete="off">
                                        <TextField id="standard-basic" label="Transfer Amount" onChange={(event) => setTransferAmount(event.target.value)}/>
                                    </form>
                                <Button variant="contained" onClick={() => transferProceeds()}>
                                    Transfer
                                </Button>

                                <Card className={classes.root}>
                                    <CardContent>
                                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                                            <Link to={{ pathname: `https://rinkeby.etherscan.io/tx/${txHash}` }} target="_blank">
                                                {txHash}
                                            </Link>
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Paper>
                        </div>

                        <div>
                            <Paper elevation={3} variant='outlined'>
                                <h3>Approve Deposit</h3>
                                <h5>Approve the deposit of proceeds to a project contract</h5>
                                <form className={classes.root} noValidate autoComplete="off">
                                    <TextField id="standard-basic" label="Project Address" onChange={(event) => setProjectContract(event.target.value)}/>
                                </form>
                                <Button variant="contained" onClick={() => approveDeposit()}>
                                    Approve
                                </Button>

                                <Card className={classes.root}>
                                    <CardContent>
                                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                                            <Link to={{ pathname: `https://rinkeby.etherscan.io/tx/${txHash}` }} target="_blank">
                                                {txHash}
                                            </Link>
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Paper>
                        </div>

                        <div>
                            <Paper elevation={3} variant='outlined'>
                                <h3>Deposit Proceeds</h3>
                                <h5>Deposit proceeds back to the project contract for investor recoupment</h5>
                                <form className={classes.root} noValidate autoComplete="off">
                                    <TextField id="standard-basic" label="Project Address" onChange={(event) => setProjectContract(event.target.value)}/>
                                </form>
                                <form className={classes.root} noValidate autoComplete="off">
                                        <TextField id="standard-basic" label="Transfer Amount" onChange={(event) => setTransferAmount(event.target.value)}/>
                                    </form>
                                <Button variant="contained" onClick={() => depositProceeds()}>
                                    Deposit
                                </Button>

                                <Card className={classes.root}>
                                    <CardContent>
                                        <Typography className={classes.title} color="textSecondary" gutterBottom>
                                            <Link to={{ pathname: `https://rinkeby.etherscan.io/tx/${txHash}` }} target="_blank">
                                                {txHash}
                                            </Link>
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Paper>
                        </div>

                    </Grid>
                </Grid>
            </Container>
        </div>
    )
}

export default AdminWeb3
