
import React, {useEffect, useState} from "react";
import { useParams, useHistory } from "react-router-dom"
import {Container, Grid} from "@material-ui/core";
import Button from "@material-ui/core/Button";
import BasicImageList from "../../components/ImageList";
import CustomLoader from "../../components/CustomLoader";
import Loader from "react-spinners/BeatLoader";

import { getDetails, completeTask } from '../../utils/projectHelpers';

const ApproveListing = () => {
    const history = useHistory();
    const {process_id, task_id, task_type} = useParams();
    const [details, setDetails] = useState(null);

    // Replace this with images
    const itemData = [
        {
            img: "https://source.unsplash.com/random",
            title: "Test title",
            author: "User Name",
            cols: 1
        },

        {
            img: "https://source.unsplash.com/random",
            title: "Test title",
            author: "User Name",
            cols: 2
        },
        {
            img: "https://source.unsplash.com/random",
            title: "Test title",
            author: "User Name",
            cols: 2
        },

        {
            img: "https://source.unsplash.com/random",
            title: "Test title",
            author: "User Name",
            cols: 1
        }
    ]

    useEffect(async () => {
        // Add and set project fetch api here
        let deets = await getDetails(process_id);
        setDetails(deets);
    }, [])

    const complete = async (task_id, task_type, decision) => {
        try {
            await completeTask(task_id, task_type, decision);
        }
        catch (ex) {
            console.log(ex)
        }
        finally {
            history.push('/admin');
        }
    }
    
    return (
        <div style={{marginTop: "40px"}}>
            <Container>
                <Grid container>
                    <Grid item xs={6} sm={6} md={6}>
                        <BasicImageList itemData={itemData}/>
                    </Grid>
                    <Grid item xs={6}>
                        <div>
                            <h2>
                                Title: {(details?.make || details?.model)
                                ? `${details?.make} - ${details?.model}`
                                : <Loader color={'black'} loading={true} size={8} margin={2} />}
                            </h2>
                        </div>

                        <div>
                            <div>Project ID:<CustomLoader data={details?.id} /></div>
                            <div>Proposed By: <CustomLoader data={details?.initiator}/></div>
                            <div>VIN Number:<CustomLoader data={details?.vin} /></div>
                            <div>Car Make: <CustomLoader data={details?.make} /></div>
                            <div>Car Model: <CustomLoader data={details?.model} /></div>
                        </div>

                        <div>
                            <div>MSRP: <CustomLoader data={details?.msrp} /></div>
                            <div>Funding Goal: <CustomLoader data={details?.fundingGoal}/></div>
                            <div></div>
                        </div>

                        {details && <Button
                            size={"medium"}
                            color={"primary"}
                            variant={"contained"}
                            onClick={async () => await complete(task_id, task_type, true)}
                        > Approve</Button>}
                        { " " }
                        {details && <Button
                            size={"medium"}
                            color={"secondary"}
                            variant={"contained"}
                            onClick={async () => await complete(task_id, task_type, false)}
                        > Deny</Button>}
                    </Grid>

                </Grid>
            </Container>
        </div>
    )
}

export default ApproveListing