import Grid from "@material-ui/core/Grid";
import Container from "@material-ui/core/Container";
import React, {useEffect, useState} from "react";
import {makeStyles} from "@material-ui/core/styles";
import AlbumCard from "./AlbumCard";
import {getProjectIds} from "../../components/Web3Interface";

const useStyles = makeStyles((theme) => ({
    icon: {
        marginRight: theme.spacing(2),
    },
    heroContent: {
        backgroundColor: theme.palette.background.paper,
        padding: theme.spacing(8, 0, 6),
    },
    heroButtons: {
        marginTop: theme.spacing(4),
    },
    cardGrid: {
        paddingTop: theme.spacing(8),
        paddingBottom: theme.spacing(8),
    },
    card: {
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
    },
    cardMedia: {
        paddingTop: '56.25%', // 16:9
    },
    cardContent: {
        flexGrow: 1,
    },
    footer: {
        backgroundColor: theme.palette.background.paper,
        padding: theme.spacing(6),
    },
}));

export default function CardList() {
    const classes = useStyles();
    const [projectIds, setProjectIds] = useState([])
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        //Call fetch api
        setLoading(true)
        getProjectIds()
            .then((data) => {
                setProjectIds(data)
            })
            .finally(() => setLoading(false))
    }, [])


    return (
        <Container className={classes.cardGrid} maxWidth="md">
            {/* End hero unit */}
            {!loading
                ? (<Grid container spacing={4}>
                    {projectIds?.map((card) => (
                        <AlbumCard
                            key={card}
                            id={card}
                        />
                    ))}
                </Grid>)
                :(
                    <Grid container spacing={4}>
                        <div style={{textAlign: "center", width: '100%'}}>
                            <h1>Fetching projects, please wait</h1>
                        </div>
                    </Grid>
                )
            }
        </Container>
    )
}

