import React from "react";
import Album from "./Album";

const Home = () => {
    return (
        <div>
            <Album />
        </div>
    )
}

export default Home