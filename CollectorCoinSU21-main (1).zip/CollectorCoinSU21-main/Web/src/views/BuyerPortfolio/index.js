
import React from "react";
import Album from "./Album";

const BuyerPortfolio = () => {
    return (
        <div>
            <Album />
        </div>
    )
}

export default BuyerPortfolio