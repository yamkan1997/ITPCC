import React, {useState} from "react";
import {Grid} from "@material-ui/core";
import styled from "styled-components";
import Button from "@material-ui/core/Button";
import Container from "@material-ui/core/Container";
import TextField from "@material-ui/core/TextField";
import {makeStyles} from "@material-ui/core/styles";
import {approveSwap, redeemTokens, swapTokens} from "../../components/Web3Interface";
import CustomSnackbar from "../../components/CustomSnackbar";

const useStyles = makeStyles((theme) => ({
    root: {
        '& > *': {
            margin: theme.spacing(1),
            width: '25ch',
        },
    },
}));

const SwapContainer = () => {

    const classes = useStyles()

    const [buyAmount, setBuyAmount] = useState('0')
    const [sellAmount, setSellAmount] = useState('0')
    const [openBuyAlert, setOpenBuyAlert] = useState(false)
    const [openSellAlert, setOpenSellAlert] = useState(false)


    function buyCC () {
        approveSwap()
            .then(() => swapTokens(buyAmount)
                .then(() => setOpenBuyAlert(true)))
    }

    function sellCC () {
        approveSwap()
            .then(() => redeemTokens(sellAmount)
                .then(() => setOpenSellAlert(true)))
    }

    return (

        <Container>
            <CustomSnackbar open={openBuyAlert} setOpen={() => setOpenBuyAlert(!openBuyAlert)} text={"Successfully bought CC, kindly wait for balance to reflect"}/>
            <CustomSnackbar open={openSellAlert} setOpen={() => setOpenSellAlert(!openSellAlert)} text={"Successfully sold CC, kindly wait for balance to reflect"}/>

            <div style={{marginTop: "40px"}}>
                <Grid container spacing={2} alignItems="center" justifyContent="space-around">
                    <Grid
                        item xs={5}
                        alignItems={"center"}
                    >
                        <StyledBox>
                            <Grid container justifyContent={'space-between'}>
                                <Grid item>
                                    <CardTitle>
                                        Buy Collector Coin
                                    </CardTitle>
                                    <CardSubtitle>
                                        Current Rate: 1 CC = $10
                                    </CardSubtitle>
                                </Grid>
                                <Grid item>
                                    <form className={classes.root} noValidate autoComplete="off">
                                        <TextField id="standard-basic" label="Amount" onChange={(event) => setBuyAmount(event.target.value)}/>
                                    </form>
                                    <Button
                                        variant="contained"
                                        color={"primary"}
                                        onClick={() => buyCC()}
                                    >
                                        Buy Now
                                    </Button>
                                </Grid>
                            </Grid>
                        </StyledBox>
                    </Grid>

                    <Grid
                        item xs={5}
                        className={"custom-swap-container"}
                        alignItems={"center"}
                    >
                        <StyledBox>
                            <Grid container justifyContent={'space-between'}>
                                <Grid item>
                                    <CardTitle>
                                        Sell Collector Coin
                                    </CardTitle>
                                    <CardSubtitle>
                                        Current Rate: 1 CC = $9.8
                                    </CardSubtitle>
                                </Grid>
                                <Grid item>
                                    <form className={classes.root} noValidate autoComplete="off">
                                        <TextField id="standard-basic" label="Amount" onChange={(event) => setSellAmount(event.target.value)}/>
                                    </form>
                                    <Button
                                        variant="contained"
                                        color={"primary"}
                                        onClick={() => sellCC()}
                                    >
                                        Sell Now
                                    </Button>
                                </Grid>
                            </Grid>
                        </StyledBox>
                    </Grid>
                </Grid>
            </div>

            <div align={"center"}>
                For successfully completing a transaction, you need to first approve the process.
            </div>

        </Container>
    )
}

export default SwapContainer;

const StyledBox = styled.div`
  width: 100%;
  padding: 24px;
  margin-bottom: 40px;
  border-radius: 8px;
  box-shadow: 1px 1px 5px rgba(0,0,0,0.5);
  &:nth-of-type(1) {
  }

`;

const CardTitle = styled.p`
    font-weight: bold;
  font-size: 18px;
`

const CardSubtitle = styled.p`
  font-size: 16px;
`

