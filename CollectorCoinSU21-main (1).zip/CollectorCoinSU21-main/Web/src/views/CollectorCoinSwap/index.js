
import React from "react";
import SwapContainer from "./SwapContainer";
import {Container} from "@material-ui/core";
import Typography from "@material-ui/core/Typography";
import {makeStyles} from "@material-ui/core/styles";


const useStyles = makeStyles((theme) => ({
    heroContent: {
        padding: theme.spacing(8, 0, 6),
    },
}));

const CollecterCoinSwap = () => {
    const classes = useStyles()

    return (
        <div>
            <div className={classes.heroContent}>
                <Container maxWidth="sm">
                    <Typography component="h1" variant="h2" align="center" color="textPrimary" gutterBottom>
                        Swap Collector Coin
                    </Typography>
                </Container>
            </div>
            <SwapContainer/>
        </div>
    )
}

export default CollecterCoinSwap