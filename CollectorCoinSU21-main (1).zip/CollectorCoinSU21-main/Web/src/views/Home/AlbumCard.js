import React, {useEffect, useState} from "react";
import Card from "@material-ui/core/Card";
import CardMedia from "@material-ui/core/CardMedia";
import CardContent from "@material-ui/core/CardContent";
import Typography from "@material-ui/core/Typography";
import CardActions from "@material-ui/core/CardActions";
import Button from "@material-ui/core/Button";
import Grid from "@material-ui/core/Grid";
import {makeStyles} from "@material-ui/core/styles";
import {getProjectDetails} from "../../components/Web3Interface";
import Loader from 'react-spinners/BeatLoader';
import CustomLoader from "../../components/CustomLoader";


const useStyles = makeStyles((theme) => ({
    icon: {
        marginRight: theme.spacing(2),
    },
    heroContent: {
        backgroundColor: theme.palette.background.paper,
        padding: theme.spacing(8, 0, 6),
    },
    heroButtons: {
        marginTop: theme.spacing(4),
    },
    cardGrid: {
        paddingTop: theme.spacing(8),
        paddingBottom: theme.spacing(8),
    },
    card: {
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
    },
    cardMedia: {
        paddingTop: '56.25%', // 16:9
    },
    cardContent: {
        flexGrow: 1,
    },
    footer: {
        backgroundColor: theme.palette.background.paper,
        padding: theme.spacing(6),
    },
}));

const AlbumCard = (props) => {
    const {id} = props;
    const classes = useStyles();
    const [details, setDetails] = useState({});

    useEffect(() => {
        getProjectDetails(id)
            .then((data) => {
                console.log(data)
                setDetails(data)
            })
    }, [id])


    if (details?.goal?.toNumber() === details?.totalDeposit?.toNumber() || details?.active === false)
    {
        return (
            <div/>
        )
    }

    return (
        <Grid item xs={12} sm={6} md={4}>
            <Card className={classes.card}>
                <CardMedia
                    className={classes.cardMedia}
                    image="https://source.unsplash.com/800x600/?car"
                    title="Image title"
                />
                <CardContent className={classes.cardContent}>
                    <Typography gutterBottom variant="h5" component="h2">
                        {(details?.make || details?.model)
                        ? `${details?.make} - ${details?.model}`
                        : <Loader color={'black'} loading={true} size={8} margin={2} />}

                    </Typography>
                    <Typography component={"span"}>
                        <br/>
                        MSRP: <CustomLoader data={details?.msrp?.toNumber()} />
                        <br/>
                        Funding Goal: <CustomLoader data={details?.goal?.toNumber()} />
                    </Typography>
                </CardContent>
                <CardActions>
                    <div align={"right"} style={{width: '100%'}}>
                        <Button size="small" color="primary" href={`/project/${id}`}>
                            Read More
                        </Button>
                    </div>
                </CardActions>
            </Card>
        </Grid>
    )
}

export default AlbumCard