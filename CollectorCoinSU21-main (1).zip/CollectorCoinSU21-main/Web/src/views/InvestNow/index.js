
import React from "react"
import Modal from "../../components/InvestModal/InvestModal"

const investNow = () => {
    return (
        <div>
            <Modal/>
        </div>
    )
}

export default investNow