
import React, {useState} from 'react';
import short from 'short-uuid';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import {callApi} from "../../apicaller";

import {startTasksFromID} from '../../utils/projectHelpers';
import CustomSnackbar from "../../components/CustomSnackbar";

const useStyles = makeStyles((theme) => ({
    paper: {
        marginTop: theme.spacing(8),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },
    form: {
        width: '100%', // Fix IE 11 issue.
        marginTop: theme.spacing(3),
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
}));

export default function NewListing() {
    const classes = useStyles();

    const [carMake, setCarMake] = useState("")
    const [carModel, setCarModel] = useState("")
    const [vin, setVin] = useState("")
    const [msrp, setMsrp] = useState("")
    const [goal, setGoal] = useState("")
    const [desc, setDesc] = useState("")
    const [openSubmitAlert, setOpenSubmitAlert] = useState(false)

    async function submitListing() {
        let id = short.generate();
        let body = {
            "id": id,
            "vin": vin,
            "make": carMake,
            "model": carModel,
            "vinMatched": true,
            "msrp": msrp,
            "fundingGoal": goal
        }

        let data;
        try {
            data = await callApi(`kie-server/services/rest/server/containers/Submission_Process_1.0.0-SNAPSHOT/processes/Submission_Process.NewListing/instances`, 'POST', body)
            if (data) {
                console.log(`created new process with id: ${data}`);
                await startTasksFromID(data)
            }
        }
        catch (ex) {
            console.log("Error submitting new listing:::");
            console.log(ex);
        } 
    }

    return (
        <Container component="main" maxWidth="xs">
            <CustomSnackbar open={openSubmitAlert} setOpen={() => setOpenSubmitAlert(!openSubmitAlert)} text={"Project submitted, please wait for our team to approve the listing"}/>

            <CssBaseline />
            <div className={classes.paper}>
                <Typography component="h1" variant="h5">
                    Submit a project
                </Typography>
                <form className={classes.form} method={"post"}>
                    <Grid container spacing={2}>
                        <Grid item xs={12} sm={6}>
                            <TextField
                                variant="outlined"
                                required
                                fullWidth
                                id="make"
                                label="Car Make"
                                name="carMake"
                                autoComplete="make"
                                onChange={(event) => setCarMake(event.target.value)}
                            />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                            <TextField
                                variant="outlined"
                                required
                                fullWidth
                                id="lastName"
                                label="Car Model"
                                name="carModel"
                                autoComplete="model"
                                onChange={(event) => setCarModel(event.target.value)}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                variant="outlined"
                                required
                                fullWidth
                                id="vin"
                                label="VI Number"
                                name="vin"
                                autoComplete="vin"
                                onChange={(event) => setVin(event.target.value)}
                            />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                            <TextField
                                type={"number"}
                                variant="outlined"
                                required
                                fullWidth
                                id="msrp"
                                label="MSRP"
                                name="msrp"
                                autoComplete="msrp"
                                onChange={(event) => setMsrp(event.target.value)}

                            />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                            <TextField
                                type={"number"}
                                variant="outlined"
                                required
                                fullWidth
                                id="goal"
                                label="Funding Goal"
                                name="goal"
                                autoComplete="goal"
                                onChange={(event) => setGoal(event.target.value)}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                variant="outlined"
                                multiline
                                rows="4"
                                required
                                fullWidth
                                id="desc"
                                label="Description"
                                name="desc"
                                autoComplete="desc"
                                onChange={(event) => setDesc(event.target.value)}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <FormControlLabel
                                control={<Checkbox value="agreeTC" color="primary" required/>}
                                label="I confirm to all the given data and agree to publish the project for fund listing"
                            />
                        </Grid>
                    </Grid>
                    <Button
                        //type="submit"
                        fullWidth
                        variant="contained"
                        color="primary"
                        className={classes.submit}
                        onClick={async () => {await submitListing()}}
                    >
                        Submit Project
                    </Button>
                </form>
            </div>

        </Container>
    );
}