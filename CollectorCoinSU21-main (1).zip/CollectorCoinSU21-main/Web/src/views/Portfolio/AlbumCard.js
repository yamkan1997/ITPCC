import React, {useEffect, useState} from "react";
import Card from "@material-ui/core/Card";
import CardMedia from "@material-ui/core/CardMedia";
import CardContent from "@material-ui/core/CardContent";
import Typography from "@material-ui/core/Typography";
import CardActions from "@material-ui/core/CardActions";
import Button from "@material-ui/core/Button";
import Grid from "@material-ui/core/Grid";
import {makeStyles} from "@material-ui/core/styles";
import {getProjectDetails, getFunderDetails, recoupFunds} from "../../components/Web3Interface";
import Loader from 'react-spinners/BeatLoader';
import CustomLoader from "../../components/CustomLoader";
import CustomSnackbar from "../../components/CustomSnackbar";


const useStyles = makeStyles((theme) => ({
    icon: {
        marginRight: theme.spacing(2),
    },
    heroContent: {
        backgroundColor: theme.palette.background.paper,
        padding: theme.spacing(8, 0, 6),
    },
    heroButtons: {
        marginTop: theme.spacing(4),
    },
    cardGrid: {
        paddingTop: theme.spacing(8),
        paddingBottom: theme.spacing(8),
    },
    card: {
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
    },
    cardMedia: {
        paddingTop: '56.25%', // 16:9
    },
    cardContent: {
        flexGrow: 1,
    },
    footer: {
        backgroundColor: theme.palette.background.paper,
        padding: theme.spacing(6),
    },
}));

const AlbumCard = (props) => {
    const {id} = props;
    const classes = useStyles();
    const [details, setDetails] = useState(null);
    const [fundingDetails, setFundingDetails] = useState(null);
    const [openRecoupAlert, setOpenRecoupAlert] = useState(false)

    useEffect(async () => {
        let data = await getProjectDetails(id);
        setDetails(data);
        let results = await getFunderDetails(id)
        setFundingDetails(results);
        console.log(results.share.toString())
    }, [id])

    function recoupAmount(projectId) {
        recoupFunds(projectId)
        .then(() => setOpenRecoupAlert(true))
    }

    if (fundingDetails && fundingDetails.share.toString() === '0')
    {
        return (
            <div/>
        )
    }
console.log(fundingDetails)
    return (
        <Grid item xs={12} sm={6} md={4}>
            <CustomSnackbar open={openRecoupAlert} setOpen={() => setOpenRecoupAlert(!openRecoupAlert)} text={"Recoup request successful, kindly wait for balance to reflect"}/>

            <Card className={classes.card}>
                <CardMedia
                    className={classes.cardMedia}
                    image="https://source.unsplash.com/800x600/?car"
                    title="Image title"
                />
                <CardContent className={classes.cardContent}>
                    <Typography gutterBottom variant="h5" component="h2">
                        {(details?.make || details?.model)
                        ? `${details?.make} - ${details?.model}`
                        : <Loader color={'black'} loading={true} size={8} margin={2} />}

                    </Typography>
                    <Typography component={"span"}>
                        <br/>
                        MSRP: <CustomLoader data={details?.msrp?.toNumber()} />
                        <br/>
                        Proceeds: {
                            (details && fundingDetails && details.redeemable) 
                            ? <CustomLoader data={details.totalDeposit.mul(fundingDetails.share).div(100).toString()} />
                            : <CustomLoader data={'Not Ready'} />
                        }
                        <br/>
                        Status: {
                            (details && details.redeemable) 
                            ? <CustomLoader data={'Ready'} />
                            : <CustomLoader data={'Funding...'} />
                        }
                    </Typography>
                </CardContent>
                <CardActions>
                    <div align={"right"} style={{width: '100%'}}>
                        {(details && details.redeemable)
                        ? <Button size="small" color="primary" onClick={() => recoupAmount(details?.id)}>
                            Redeem
                        </Button>
                        : <Button size="small" color="primary" disabled>
                            Redeem
                        </Button>
                        }
                    </div>
                </CardActions>
            </Card>
        </Grid>
    )
}

export default AlbumCard