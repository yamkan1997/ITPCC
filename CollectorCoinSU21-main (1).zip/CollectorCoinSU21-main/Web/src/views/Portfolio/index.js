
import React from "react";
import Album from "./Album";

const Portfolio = () => {
    return (
        <div>
            <Album />
        </div>
    )
}

export default Portfolio