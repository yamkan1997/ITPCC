
import React, {useEffect, useState} from "react";
import { useParams } from "react-router-dom"
import {Container, Grid} from "@material-ui/core";
import Button from "@material-ui/core/Button";
import BasicImageList from "../../components/ImageList";
import InvestModal from "../../components/InvestModal/InvestModal";
import {getProjectDetails} from "../../components/Web3Interface";
import CustomLoader from "../../components/CustomLoader";
import Loader from "react-spinners/BeatLoader";

const Project = () => {
    const {project_id} = useParams()
    const [openModal, setOpenModal] = useState(false);
    const [details, setDetails] = useState(null);

    useEffect(() => {
        getProjectDetails(project_id)
            .then((data) => {
                console.log(data)
                setDetails(data)
            })
    }, [project_id])

    // Replace this with images
    const itemData = [
        {
            img: "https://source.unsplash.com/random",
            title: "Test title",
            author: "User Name",
            cols: 1
        },

        {
            img: "https://source.unsplash.com/random",
            title: "Test title",
            author: "User Name",
            cols: 2
        },
        {
            img: "https://source.unsplash.com/random",
            title: "Test title",
            author: "User Name",
            cols: 2
        },

        {
            img: "https://source.unsplash.com/random",
            title: "Test title",
            author: "User Name",
            cols: 1
        }
    ]

    useEffect(() => {
        // Add and set project fetch api here
    }, [project_id])

    return (
        <div style={{marginTop: "40px"}}>
            <Container>
                <Grid container>
                    <Grid item xs={6} sm={6} md={6}>
                        <BasicImageList itemData={itemData}/>
                    </Grid>
                    <Grid item xs={6}>
                        <div>
                            <h2>
                                Title: {(details?.make || details?.model)
                                ? `${details?.make} - ${details?.model}`
                                : <Loader color={'black'} loading={true} size={8} margin={2} />}
                            </h2>
                        </div>

                        <div>
                            <div><b>Description: </b> This is a test description</div>
                        </div>

                        <div>
                            <div>VI Number:<CustomLoader data={details?.vin} /></div>
                            <div>Car Make: <CustomLoader data={details?.make} /></div>
                            <div>Car Model: <CustomLoader data={details?.model} /></div>
                            <div>Paint Code: </div>
                        </div>

                        <div>
                            <div>MSRP: <CustomLoader data={details?.msrp?.toNumber()} /></div>
                            <div>Funding Goal: <CustomLoader data={details?.goal?.toNumber()}/></div>
                            <div>Current Funding: <CustomLoader data={details?.totalDeposit?.toNumber()}/></div>
                            <div>Funding Remaining: <CustomLoader data={details?.goal?.toNumber() - details?.totalDeposit?.toNumber()} /></div>
                        </div>

                        {details && <Button
                            size={"medium"}
                            color={"primary"}
                            variant={"contained"}
                            onClick={() => setOpenModal(true)}
                        > Invest Now</Button>}
                    </Grid>

                </Grid>
            </Container>
            <InvestModal
                openModal={openModal}
                onClose={() => setOpenModal(false)}
                details={details}
            />
        </div>
    )
}

export default Project